package entidades;

public class FechaVencidaException extends Exception {
    public FechaVencidaException(String mensaje) {
        super(mensaje);
    }
}
